// 同步commit
export const SET_MUTATION_DEFAULT = 'SET_MUTATION_DEFAULT';
export const SET_MUTATION_END = 'SET_COMMIT_END';

export const SET_MUTATION_RANDOM = 'SET_MUTATION_RANDOM'

// 显示隐藏 loading
export const IS_SHOW_LOADING = 'IS_SHOW_LOADING';

// 显示隐藏 Toast 同步
export const SYNC_IS_SHOW_TOAST = 'SYNC_IS_SHOW_TOAST';