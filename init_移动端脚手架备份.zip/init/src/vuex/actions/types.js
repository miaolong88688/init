// 异步action
export const SET_ACTION_DEFAULT = 'SET_ACTION_DEFAULT';
export const SET_ACTION_END = 'SET_ACTION_END';


// 显示隐藏 Toast 异步
export const ASYNC_IS_SHOW_TOAST = 'ASYN_IS_SHOW_TOAST';