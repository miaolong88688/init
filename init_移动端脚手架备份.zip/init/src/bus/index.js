import Vue from 'vue';

const bus = new Vue();

const busType = {
    DEFAULT: "DEFAULT"
}

export {
    bus,
    busType
}