module.exports = {
    isEnv: process.env.NODE_ENV === 'development' ? true : false,
    env: process.env.NODE_ENV,
    // 开发环境base
    envBaseUrl: 'https://www.easy-mock.com/mock/5a0915e8c645f1227829960e/example',
    // 生产环境base
    prodbBaseUrl: 'https://www.easy-mock.com/mock/5a0915e8c645f1227829960e/example'
} 
