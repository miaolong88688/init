<template>
    <div class="header">
        
    </div>
</template>

<script>
export default {
    name: 'myHeader'
}
</script>

<style lang="less" src="./index.less" scoped>


</style>