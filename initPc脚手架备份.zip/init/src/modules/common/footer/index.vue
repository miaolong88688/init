<template>
    <div class="footer">

    </div>
</template>

<script>
export default {
    name: 'myFooter'
}
</script>

<style lang="less" src="./index.less" scoped>


</style>