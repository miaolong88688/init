export const defaultGET = '/user';
export const defaultPOST = '/upload';
export const defaultRandom = '/mock'; 