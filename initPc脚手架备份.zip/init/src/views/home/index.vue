<template>
    <div>
        {{test}}
    </div>
</template>
<script>

import * as connectURL from "@/http/common/connectURL";
import * as mutationTypes from "@/vuex/mutations/types";
import * as actionTypes from "@/vuex/actions/types";
import { 
  mapState, 
  mapGetters, 
  mapMutations, 
  mapActions 
} from "vuex";

export default {
  name: "home",
  data() {
    return {
      test: "初始化PC"
    };
  },
  computed: {
    ...mapState(["count"]),
    ...mapGetters(["calcNumber"]),
    currentComputed() {
      return this.msg;
    }
  },
  mounted() {
    this.$http(connectURL.defaultGET)
    .then(res => {
      console.log( res )
    })
    .catch(err => {
      this.$toast.show(err.message);
    })
  },
  methods: {
    ...mapMutations({
      triggerMutation: mutationTypes.SET_MUTATION_DEFAULT
    }),
    ...mapActions({
      triggerAction: actionTypes.SET_ACTION_DEFAULT
    })
  }
};
</script>

<style lang="less" src="./index.less"> </style>