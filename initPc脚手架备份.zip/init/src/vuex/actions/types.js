// 异步action
export const SET_ACTION_DEFAULT = 'SET_ACTION_DEFAULT';
export const SET_ACTION_END = 'SET_ACTION_END';
