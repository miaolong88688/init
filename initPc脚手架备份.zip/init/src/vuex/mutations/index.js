import * as mutationTypes from './types';

// Mutation
const mutations = function ( state ) {
    return {
        [mutationTypes.SET_MUTATION_DEFAULT]: function( state ) {
            state.count ++
        },
        [mutationTypes.SET_MUTATION_RANDOM]: function ( state, options ) {
            state.resultData = options;
        }
    }
}
export default mutations